﻿//------------------------------------------------------------
// Game Framework
// Copyright © 2013-2018 Jiang Yin. All rights reserved.
// Homepage: http://gameframework.cn/
// Feedback: mailto:jiangyin@gameframework.cn
// Excel表自动转txt配置文本和class类工具 泡泡糖
//------------------------------------------------------------

using System.Collections.Generic;

#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using OfficeOpenXml;
using System.IO;
using System.Text;
#endif



public static class AutoExcel2Tsv2Class
{

#if UNITY_EDITOR

    #region 在这里配置输入输出相关内容

    /// <summary>
    /// 配置Excel表的目录
    /// </summary>
    const string INPUT_EXCEL_FILE_PATH = "GameMain/DataTables_Excel";
    /// <summary>
    /// 配置生成类的命名空间名
    /// </summary>
    const string INPUT_CLASS_NAMESPACE = "StarForce";
    /// <summary>
    /// 配置生成的表格文本的存放目录
    /// </summary>
    const string OUTPUT_TSV_FILE_PATH = "GameMain/DataTables";
    /// <summary>
    /// 配置生成的表格模型类的存放目录
    /// </summary>
    const string OUTPUT_CLASS_FILE_PATH = "GameMain/Scripts/DataTable";

    #endregion

    #region 生成实现

    const string EXCEL_EXTENSION = "xlsx";
    const string TSV_EXTENSION = "txt";
    const char ADD_FILE_SEPERATOR = '+';

    [MenuItem("Game Framework/AutoExcel2Tsv2Class/Excel2Tsv")]
    static void Excel2Tsv()
    {
        Debug.Log("开始生成配置文本");
        string[] excelFilePaths = Directory.GetFiles(
            GameFramework.Utility.Path.GetCombinePath(Application.dataPath, INPUT_EXCEL_FILE_PATH),string.Format("*.{0} ", EXCEL_EXTENSION));
        //将增加文件放到后面
        System.Array.Sort(excelFilePaths);

        for (int i = 0; i < excelFilePaths.Length; i++)
        {
            var excelFile = new FileInfo(excelFilePaths[i]);
            Debug.LogFormat("正在生成表:{0}", excelFile.Name);
            var arr = excelFile.Name.Replace(string.Format(".{0}", EXCEL_EXTENSION), string.Empty).Split(ADD_FILE_SEPERATOR);
            var isAddFile = arr.Length > 1;
            var tableName = arr[0];

            var tsvFilePath = GameFramework.Utility.Path.GetCombinePath(
                Application.dataPath,
                string.Format("{0}/{1}.txt", OUTPUT_TSV_FILE_PATH, tableName));

            ExcelWorksheet sheet = null;
            try
            {
                ExcelPackage excel = new ExcelPackage(excelFile);
                sheet = excel.Workbook.Worksheets[1];
            }
            catch (System.Exception)
            {
                Debug.LogErrorFormat("错误的Excel表或工作薄:{0}", excelFile.Name);
                continue;
            }

            GenerateTsvFile(tsvFilePath, sheet, isAddFile);
        }

        AssetDatabase.Refresh();
        Debug.Log("生成配置文本成功");
    }

    [MenuItem("Game Framework/AutoExcel2Tsv2Class/Excel2Class")]
    static void Excel2Class()
    {
        Debug.Log("开始生成配置表格的模型类");
        string[] excelFilePaths = Directory.GetFiles(
            GameFramework.Utility.Path.GetCombinePath(Application.dataPath, INPUT_EXCEL_FILE_PATH), string.Format("*.{0} ", EXCEL_EXTENSION));

        for (int i = 0; i < excelFilePaths.Length; i++)
        {
            var excelFile = new FileInfo(excelFilePaths[i]);
            var arr = excelFile.Name.Replace(string.Format(".{0}", EXCEL_EXTENSION), string.Empty).Split(ADD_FILE_SEPERATOR);
            var isAddFile = arr.Length > 1;
            var tableName = arr[0];
            tableName = string.Format("DR{0}", tableName);

            if (isAddFile)
                continue;

            Debug.LogFormat("正在生成类:{0}", tableName);
            ExcelWorksheet sheet = null;
            try
            {
                ExcelPackage excel = new ExcelPackage(excelFile);
                sheet = excel.Workbook.Worksheets[1];
            }
            catch (System.Exception)
            {
                Debug.LogErrorFormat("错误的Excel表或工作薄:{0}", excelFile.Name);
                continue;
            }
            
            StringBuilder propStr = new StringBuilder();
            StringBuilder parseStr = new StringBuilder();
            GeneratePropertyAndParseStr(sheet, propStr, parseStr);

            var classFilePath = GameFramework.Utility.Path.GetCombinePath(
                Application.dataPath,
                string.Format("{0}/{1}.cs", OUTPUT_CLASS_FILE_PATH, tableName));

            var classStr = new StringBuilder(CLASS_TEMPLATE);
            classStr = classStr.Replace(CLASS_NAMESPACE_PLACEHOLDER, INPUT_CLASS_NAMESPACE);
            classStr = classStr.Replace(CLASS_CLASSNAME_PLACEHOLDER, tableName);
            classStr = classStr.Replace(CLASS_CLASS_DESCRIPTION_PLACEHOLDER, sheet.Cells[1, 1].Text);
            classStr = classStr.Replace(CLASS_PROPERTIES_PLACEHOLDER, propStr.ToString());
            classStr = classStr.Replace(CLASS_PARSEDATA_PLACEHOLDER, parseStr.ToString());

            FileStream fs = new FileStream(classFilePath, FileMode.Create);
            var bytes = Encoding.UTF8.GetBytes(classStr.ToString());
            fs.Write(bytes, 0, bytes.Length);
            fs.Close();
            fs.Dispose();
        }

        AssetDatabase.Refresh();
        Debug.Log("生成配置表格的模型类成功");
    }


    [MenuItem("Game Framework/AutoExcel2Tsv2Class/Excel2Tsv2Class")]
    static void Excel2Tsv2Class()
    {
        Excel2Tsv();
        Excel2Class();
    }


    private static void GeneratePropertyAndParseStr(ExcelWorksheet sheet, StringBuilder propStr, StringBuilder parseStr)
    {
        int inUseCollums = GetLastCollumIndex(sheet);
        
        //第一列是Id跳过,第二列是策划备注跳过
        for (int pi = 3; pi <= inUseCollums; pi++)
        {
            string pname = sheet.Cells[2, pi].Text;
            string ptype = sheet.Cells[3, pi].Text;
            string pcomment = sheet.Cells[4, pi].Text;
            propStr.Append(string.Format(CLASS_PROPERTY_ITEM_FORMAT, pcomment, ptype, pname));

            const string parseCurStr = "text[index++]";
            switch (ptype)
            {
                case "string":
                    parseStr.Append(string.Format(CLASS_PARSE_COMMON_ITEM_FORMAT, pname, parseCurStr));
                    break;
                case "int":
                case "float":
                case "bool":
                    parseStr.Append(string.Format(CLASS_PARSE_COMMON_ITEM_FORMAT, pname,
                        string.Format("{0}.Parse({1})", ptype, parseCurStr)));
                    break;
                default:
                    parseStr.Append(string.Format(CLASS_PARSE_OBJECT_ITEM_FORMAT, pname, ptype, parseCurStr));
                    break;
            }
        }
    }

    private static bool WriteString(FileStream fs,  string str, bool newRow = false, bool newCol = false)
    {
        try
        {
            var bytes = Encoding.UTF8.GetBytes(string.Format("{0}{1}{2}", str, newRow?"\n":string.Empty, newCol?"\t":string.Empty));
            fs.Write(bytes, 0, bytes.Length);
        }
        catch (System.Exception)
        {
            return false;
        }
        return true;
    }

    private static void GenerateTsvFile(string tsvFilePath, ExcelWorksheet sheet, bool append)
    {
        //有用的列数
        int inUseCollom = GetLastCollumIndex(sheet);

        FileStream fs = null;
        //不是添加或者文件不存在都新建
        if (!append || !File.Exists(tsvFilePath))
        {
            fs = new FileStream(tsvFilePath, FileMode.Create);

            //写标题行
            var title = sheet.Cells[1, 1].Text;
            WriteString(fs, "#", false, true);
            WriteString(fs, title, true, false);

            //字段名行、注释
            WriteCommonRows(sheet, fs, inUseCollom);
        }
        else
        {
            fs = new FileStream(tsvFilePath, FileMode.Open);
            fs.Seek(0, SeekOrigin.End);
        }

        //内容行
        WriteDataRows(sheet, fs, inUseCollom);

        fs.Close();
        fs.Dispose();
    }

    private static void WriteCommonRows(ExcelWorksheet sheet, FileStream fs, int inUseCollom)
    {
        var end = sheet.Dimension.End;
        for (int ri = 2; ri <= 4; ri++)
        {
            WriteString(fs, "#", false, true);
            WriteTrueCollums(sheet, fs, end, inUseCollom, ri);
        }
    }

    private static void WriteDataRows(ExcelWorksheet sheet, FileStream fs, int inUseCollom)
    {
        var end = sheet.Dimension.End;
        for (int ri = 5; ri <= end.Row; ri++)
        {
            if (string.IsNullOrEmpty(sheet.Cells[ri, 1].Text))
                break;
            //字段和注释行加#
            if (sheet.Cells[ri, 1].Text.StartsWith("#", System.StringComparison.Ordinal))
                continue;

            WriteString(fs, string.Empty, false, true);
            WriteTrueCollums(sheet, fs, end, inUseCollom, ri);
        }
    }

    private static void WriteTrueCollums(ExcelWorksheet sheet, FileStream fs, ExcelCellAddress end, int inUseCollom, int ri)
    {
        for (int ci = 1; ci < inUseCollom; ci++)
        {
            var str = sheet.Cells[ri, ci].Text;
            if (str.Contains("\n")) str = RecoverBreakLineInTsv(str, true);
            WriteString(fs, str, false, true);
        }
        var lastColStr = sheet.Cells[ri, end.Column].Text;
        if (lastColStr.Contains("\n")) lastColStr = RecoverBreakLineInTsv(lastColStr, true);
        WriteString(fs, lastColStr, true, false);
    }

    private static int GetLastCollumIndex(ExcelWorksheet sheet)
    {
        int inUseCollom = 1;
        var end = sheet.Dimension.End;
        for (; inUseCollom <= end.Column; inUseCollom++)
        {
            var filedName = sheet.Cells[2, inUseCollom].Text;
            if (string.IsNullOrEmpty(filedName))
                return inUseCollom - 1;
        }

        return inUseCollom - 1;
    }

    #endregion

    #region 输出类的模板内容

    private const string CLASS_NAMESPACE_PLACEHOLDER = "[[--namespace--]]";
    private const string CLASS_CLASSNAME_PLACEHOLDER = "[[--classname--]]";
    private const string CLASS_CLASS_DESCRIPTION_PLACEHOLDER = "[[--classdescription--]]";
    private const string CLASS_PROPERTIES_PLACEHOLDER = "[[--properties--]]";
    private const string CLASS_PARSEDATA_PLACEHOLDER = "[[--parsedata--]]";
    private const string CLASS_PROPERTY_ITEM_FORMAT = @"
        /// <summary>
        /// {0}
        /// </summary>
        public {1} {2}
        {{
            get;
            private set;
        }}
";
    private const string CLASS_PARSE_COMMON_ITEM_FORMAT = @"
            {0} = {1};
";
    private const string CLASS_PARSE_OBJECT_ITEM_FORMAT = @"
            {0} = null;
            {0} = {0}.CreateFromString({2});";
    private const string CLASS_TEMPLATE = @"
using GameFramework.DataTable;
using System.Collections.Generic;

namespace [[--namespace--]]
{
    /// <summary>
    /// [[--classdescription--]]
    /// </summary>
    public class [[--classname--]] : IDataRow
    {
        /// <summary>
        /// 编号
        /// </summary>
        public int Id
        {
            get;
            protected set;
        }

        [[--properties--]]

        public void ParseDataRow(string dataRowText)
        {
            //回车还原
            if (dataRowText.Contains(AutoExcel2Tsv2Class.BREAK_LINE_PLACEHOLDER))
                dataRowText = AutoExcel2Tsv2Class.RecoverBreakLineInTsv(dataRowText);
            string[] text = DataTableExtension.SplitDataRow(dataRowText);
            int index = 0;
            index++;
            Id = int.Parse(text[index++]);
            index++;
[[--parsedata--]]
        }

        private void AvoidJIT()
        {
            new Dictionary<int, [[--classname--]]>();
        }
    }
}
";

    #endregion

#endif

    #region Excel支持字段类型的扩展实现

    public static string[] CreateFromString(this string[] arr, string str)
    {
        arr = str.Split(',');
        for (int i = 0; i < arr.Length; i++)
        {
            arr[i] = arr[i].Trim();
        }
        return arr;
    }
    public static int[] CreateFromString(this int[] arr, string str)
    {
        var strArr = str.Split(',');
        arr = new int[strArr.Length];
        for (int i = 0; i < arr.Length; i++)
        {
            arr[i] = int.Parse(strArr[i].Trim());
        }
        return arr;
    }
    public static float[] CreateFromString(this float[] arr, string str)
    {
        var strArr = str.Split(',');
        arr = new float[strArr.Length];
        for (int i = 0; i < arr.Length; i++)
        {
            arr[i] = float.Parse(strArr[i].Trim());
        }
        return arr;
    }
    public static bool[] CreateFromString(this bool[] arr, string str)
    {
        var strArr = str.Split(',');
        arr = new bool[strArr.Length];
        for (int i = 0; i < arr.Length; i++)
        {
            arr[i] = bool.Parse(strArr[i].Trim());
        }
        return arr;
    }
    public static Dictionary<int, string> CreateFromString(this Dictionary<int, string> dic, string str)
    {
        var strArr = str.Split(',');
        dic = new Dictionary<int, string>();
        foreach (var item in strArr)
        {
            var kvpArr = item.Split(':');
            dic.Add(int.Parse(kvpArr[0].Trim()), kvpArr[1].Trim());
        }
        return dic;
    }
    public static string RecoverBreakLineInTsv(string raw, bool invert = false)
    {
        if(!invert)
            return raw.Replace(BREAK_LINE_PLACEHOLDER, "\n");
        return raw.Replace("\n", BREAK_LINE_PLACEHOLDER);
    }
    public const string BREAK_LINE_PLACEHOLDER = "\\n";

    #endregion
}


