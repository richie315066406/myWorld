功能：
1.自动将Excel转为GameFramework认识的txt的配置文本，并可生成对应的DR类。
2.支持集合数据类型，并可扩展自定义类，参考AutoExcel2Tsv2Class.cs末尾的扩展实现。
3.支持多表自动合并，方便Excel多人合作。如Billboard.xlsx是基础表，另外可以有Billboard+lily.xlsx由lily编辑，Billboard+lucy由lucy编辑，在生成时会自动合并到Billboard.txt中。注表结构需要一样，且Id不要重复。
4.支持Excel配置内容分段/换行。
5.支持行注释。

用法：
1.将"Epplus.dll"放到适当的目录中（用于读取Excel），并在检视面板中将"IncludePlatforms"设置为"Editor"，因为我们只在编辑器中使用。
	以StarForce为例，可以放在GameMain/Libraries下。
2.将Excel文件放到适当的目录中。
	以StarForce为例，我将Billboard.xlsx可以放在GameMain/DataTables_Excel中（挨着DataTables新建的）。
3.交"AutoExcel2Tsv2Class.cs"放到适当目录中（功能实现类）,请不要放在Editor目录下，因为集合等数据类型的扩展方法，在运行时会用到。
	以StarForce为例，可以放到GameMain/Scripts/Utility下。
4.在"AutoExcel2Tsv2Class.cs"类开头的部分配置生成内容的存放目录。
	留默认配置以是StarForce为蓝本。
5.可以使用了，在"GameFramework"菜单下，通过”AutoExcel2Tsv2Class"生成吧。


也参考了其它框架的表格处理方法，向无数开源的前辈致敬。
初次发布东西，问题难免，请多指教。
